# 财务总监分析框架

## 财务总监思维模式

### 1. 财务数据分析思维
财务总监的核心工作之一是分析财务数据，包括：
- **精确财务数据获取**：使用baostock/akshare获取上市公司财务数据
- **财务指标计算**：计算ROE、净利率、毛利率、资产周转率、负债率等指标
- **财务趋势分析**：分析营收增长率、净利润增长率、毛利率变化趋势

### 2. 战略财务分析思维
财务总监需要从战略层面分析财务：
- **波特五力模型分析**：
  - 供应商议价能力
  - 买方议价能力
  - 新进入者威胁
  - 替代品威胁
  - 行业内竞争
- **杜邦分析**：
  - ROE分解（净利率×资产周转率×权益乘数）
- **现金流分析**：
  - 现金流与净利润关系
  - 现金资产占比
  - 经营活动现金流比率
- **估值分析**：
  - 市盈率（PE）分析
  - 市净率（PB）分析
  - PEG分析
  - DCF估值

### 3. 风险控制思维
财务总监负责企业风险管理：
- **财务风险评估**：
  - 负债率风险评估
  - 现金流风险评估
  - 应收账款风险评估
  - 存货风险评估
- **套期保值分析**：
  - 原材料套期保值业务利润分配
  - 套期保值业务风险控制
- **风险预警机制**：
  - 财务风险预警机制
  - 运营风险预警机制
  - 市场风险预警机制

### 4. 资源投放思维
财务总监负责资源投放规划：
- **资源投放规划**：
  - 研发投入规划
  - 市场拓展规划
  - 产能扩张规划
  - 数字化转型规划
- **投资回报分析**：
  - 投资回报率（ROI）分析
  - 投资回收期分析
  - 投资风险分析
- **资源配置优化**：
  - 财务资源配置优化
  - 人力资源配置优化
  - 资产配置优化

### 5. 国际战略思维
财务总监参与国际战略规划：
- **国际市场选择**：
  - 国际市场选择标准
  - 国际市场评估
  - 国际市场进入策略
- **业务模块选择**：
  - 业务模块选择标准
  - 业务模块评估
  - 业务模块发展策略
- **成功模式复制**：
  - 成功模式分析
  - 成功模式复制策略
  - 成功模式复制风险评估

## 财务总监分析框架

### 上市公司财务数据分析框架

#### 1. 营收增长速度分析
- **营收增长率计算公式**：`营收增长率 = (本期营收 - 基期营收) / 基期营收`
- **营收增长质量分析**：增长是真实的业务增长还是来自会计调整
- **营收增长来源分析**：哪个业务板块贡献了最大增长
- **营收增长趋势分析**：增长是否可持续

#### 2. 净利润增长速度分析
- **净利润增长率计算公式**：`净利润增长率 = (本期净利润 - 基期净利润) / 基期净利润`
- **净利率变化分析**：净利率是否随着营收增长而提升
- **净利润质量分析**：净利润增长是否来自主营业务
- **净利润可持续性分析**：增长是否可持续

#### 3. 主营业务收入结构变化
- **业务板块占比变化分析**：
  - 家电业务占比变化
  - 智能家居业务占比变化
  - 高端品牌占比变化
  - 国际化业务占比变化
- **毛利率变化分析**：不同业务板块的毛利率变化
- **业务成长性分析**：哪个业务板块有成长潜力

#### 4. 前十股东变化分析
- **主要股东持股变化分析**：
  - 控股股东持股变化
  - 机构投资者持股变化
  - 个人投资者持股变化
- **股权集中度变化分析**：股权是否在集中
- **股权架构调整可能性分析**：是否存在股权架构调整的计划

#### 5. 套期保值业务利润分配
- **原材料套期保值业务规模分析**：对钢材、塑料等原材料进行的套期保值规模
- **套期保值利润分配分析**：套期保值业务产生的利润如何分配和使用
- **风险管理分析**：套期保值业务的风险管理措施

#### 6. 未来三年资源投放计划
- **研发投入计划分析**：智能家居研发投入计划
- **市场拓展投入计划分析**：国际市场拓展投入计划
- **产能扩张投入计划分析**：产能扩张的投资计划
- **数字化转型投入计划分析**：数字化转型的投资计划
- **投资回报率分析**：各项投资的预计回报率

#### 7. 营收和净利润目标
- **营收目标分析**：未来三年的营收增长目标
- **净利润目标分析**：未来三年的净利润增长目标
- **目标可行性分析**：目标是否现实可行
- **风险因素分析**：实现目标面临的风险因素

#### 8. 现金流健康计划
- **现金流管理策略分析**：现金流管理策略
- **现金流优化措施分析**：提升现金流的措施
- **现金流目标分析**：现金流健康的具体目标
- **现金流动性分析**：现金流动性是否充足

#### 9. 国际市场开拓策略
- **国际市场选择分析**：重点开拓的国际市场地区
- **市场进入策略分析**：市场进入的具体策略
- **产品策略分析**：在国际市场销售的产品策略
- **渠道策略分析**：在国际市场的渠道策略
- **财务支持分析**：国际市场开拓的财务支持

#### 10. 战略目光聚焦的地区和业务模块
- **战略聚焦地区分析**：国际战略聚焦的具体地区
- **战略聚焦业务模块分析**：国际战略聚焦的具体业务模块
- **成功模式复制分析**：在国际市场成功后的模式复制计划
- **财务资源配置分析**：如何为战略聚焦分配财务资源

## 财务总监分析模板

### 海尔智家财务总监分析模板

```python
# 海尔智家财务总监分析模板
def haier_finance_director_analysis():
    # 财务数据获取
    finance_data = get_finance_data("sh.600690")
    
    # 财务指标计算
    roe = calculate_roe(finance_data["netProfit"], finance_data["equity"])
    np_margin = calculate_np_margin(finance_data["netProfit"], finance_data["revenue"])
    gp_margin = calculate_gp_margin(finance_data["grossProfit"], finance_data["revenue"])
    
    # 财务趋势分析
    revenue_growth = calculate_revenue_growth(finance_data["currentRevenue"], finance_data["previousRevenue"])
    net_profit_growth = calculate_net_profit_growth(finance_data["currentNetProfit"], finance_data["previousNetProfit"])
    
    # 波特五力模型分析
    porter_analysis = porter_five_force_analysis(finance_data)
    
    # 杜邦分析
    dupont_analysis = dupont_roe_analysis(np_margin, finance_data["assetTurnover"], finance_data["equityMultiplier"])
    
    # 现金流分析
    cashflow_analysis = cashflow_analysis(finance_data["cfo"], finance_data["netProfit"], finance_data["revenue"])
    
    # 估值分析
    valuation_analysis = valuation_analysis(finance_data["eps"], finance_data["roe"], finance_data["npMargin"])
    
    # 风险控制分析
    risk_analysis = risk_control_analysis(finance_data["liabilityRatio"], finance_data["cashflowRatio"], finance_data["inventoryRatio"])
    
    # 资源投放分析
    resource_analysis = resource_allocation_analysis(finance_data["rdInvestment"], finance_data["marketInvestment"], finance_data["capacityInvestment"])
    
    # 国际战略分析
    international_strategy_analysis = international_strategy_analysis(finance_data["internationalRevenue"], finance_data["internationalProfit"])
    
    # 财务总监建议
    suggestions = finance_director_suggestions(roe, np_margin, gp_margin, revenue_growth, net_profit_growth, porter_analysis, dupont_analysis, cashflow_analysis, valuation_analysis, risk_analysis, resource_analysis, international_strategy_analysis)
    
    return suggestions
```

### 财务总监建议模板

```python
# 财务总监建议模板
def finance_director_suggestions(roe, np_margin, gp_margin, revenue_growth, net_profit_growth, porter_analysis, dupont_analysis, cashflow_analysis, valuation_analysis, risk_analysis, resource_analysis, international_strategy_analysis):
    suggestions = []
    
    # 成本控制建议
    if gp_margin < 30:
        suggestions.append("加强成本控制")
    
    # 现金流优化建议
    if cashflow_analysis["cfo_to_np"] < 1:
        suggestions.append("优化现金流结构")
    
    # 净利率提升建议
    if np_margin < 8:
        suggestions.append("提高净利率")
    
    # ROE保持建议
    if roe < 15:
        suggestions.append("保持ROE水平")
    
    # 国际市场开拓建议
    if international_strategy_analysis["internationalRevenueRatio"] < 20:
        suggestions.append("国际市场开拓")
    
    # 股权架构调整建议
    if risk_analysis["liabilityRatio"] < 50:
        suggestions.append("股权架构调整")
    
    # 套期保值业务利润分配建议
    if risk_analysis["hedgingProfit"] > 0:
        suggestions.append("套期保值业务利润分配")
    
    # 营收和净利润增长目标建议
    if revenue_growth < 15:
        suggestions.append("营收增长目标15-20%")
    
    if net_profit_growth < 20:
        suggestions.append("净利润增长目标20-25%")
    
    # 现金流健康计划建议
    suggestions.append("现金流健康计划")
    
    # 国际战略聚焦建议
    suggestions.append("国际战略聚焦")
    
    return suggestions
```

## 财务总监分析示例

### 海尔智家财务总监分析示例

```python
# 海尔智家财务总监分析示例
haier_results = haier_finance_director_analysis()

print("=== 海尔智家财务总监分析 ===")
print("财务指标:")
print(f"ROE: {haier_results['roe']}")
print(f"净利率: {haier_results['np_margin']}")
print(f"毛利率: {haier_results['gp_margin']}")
print(f"营收增长率: {haier_results['revenue_growth']}")
print(f"净利润增长率: {haier_results['net_profit_growth']}")
print(f"负债率: {haier_results['liability_ratio']}")
print(f"现金流与净利润比率: {haier_results['cfo_to_np']}")

print("\n财务总监建议:")
for suggestion in haier_results['suggestions']:
    print(f"- {suggestion}")

print("\n估值判断:")
print(f"市盈率: {haier_results['pe']}")
if haier_results['valuation_analysis']['结论'] == "股价不算高估":
    print("股价20.85元不算高估")
else:
    print("股价20.85元可能高估")
```

## 财务总监决策框架

### 财务总监决策框架

1. **财务数据获取**：获取上市公司财务数据
2. **财务指标计算**：计算财务指标
3. **财务趋势分析**：分析财务趋势
4. **战略财务分析**：波特五力模型分析、杜邦分析、现金流分析
5. **估值分析**：市盈率、市净率、PEG、DCF估值
6. **风险控制分析**：财务风险评估、套期保值分析
7. **资源投放分析**：资源投放规划、投资回报分析
8. **国际战略分析**：国际市场选择、业务模块选择
9. **财务总监建议**：提出财务总监级别建议
10. **估值判断**：判断股价是否高估

这个框架适用于所有上市公司，包括海尔智家、美的集团、格力电器等家电企业，以及其他行业的上市公司。